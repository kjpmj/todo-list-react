import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <div>
        <a href='#'>ALL</a>
        <a href='#'>COPLETED</a>
        <a href='#'>ACTVIE</a> 
      </div>
    );
  }
}

export default Footer;