import React, { Component } from 'react';
import TodoList from './components/TodoList';
import AddForm from './components/AddForm';
import Footer from './components/Footer';

class App extends Component {
  id = 0;
  state = {
    todos : []
  }

  handleTodoClick = (changeTodo) => {
    const { todos } = this.state;
    this.setState({
      todos : todos.map(todo =>
        changeTodo.id === todo.id 
          ? {...todo, ...changeTodo}
          : todo
      )
    });
  }

  handleAddSubmit = (text) => {
    const { todos } = this.state;
    this.setState({
      todos : todos.concat({id : this.id++ , text: text, completed : false})
    });
  }
  
  render() {
    const { todos } = this.state;

    return (
      <div>
        <AddForm
          onAddSubmit={this.handleAddSubmit}
        />
        <TodoList
          todos={todos}
          onTodoClick={this.handleTodoClick}
        />
        <Footer
          
        />
      </div>
    );
  }
}

export default App;
